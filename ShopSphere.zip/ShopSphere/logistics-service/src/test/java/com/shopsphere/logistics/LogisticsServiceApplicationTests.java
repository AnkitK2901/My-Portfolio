package com.shopsphere.logistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogisticsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
