package com.shopsphere.order.Service;

import com.shopsphere.order.DTO.*;
import com.shopsphere.order.Entity.OrderEntity;
import com.shopsphere.order.Enums.OrderStatus;
import com.shopsphere.order.Exception.ResourceNotFoundException;
import com.shopsphere.order.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OrderServiceImpl implements OrderService{

    @Autowired
    private UserClient userClient;

    @Autowired
    private ProductClient productClient;

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public List<OrderResponse> getAllOrders(){
        return orderRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public OrderResponse getOrderById(Long orderId){
        OrderEntity order =  orderRepository.findById(orderId)
                .orElseThrow(()-> new ResourceNotFoundException("Order ID is not Found"));
        return mapToResponse(order);
    }

    @Override
    public OrderResponse placeOrder(OrderRequest orderRequest){

        ProductDTO product = productClient.findProductById(orderRequest.getProductId());
        UserDTO user = userClient.getUserByUserName(orderRequest.getUserName());

        if(user == null){
            throw new ResourceNotFoundException("Customer Not found");
        }

        if(product == null){
            throw new ResourceNotFoundException("Product Not Found");
        }

        if (product.getTotalPrice() == null) {
            throw new IllegalStateException("Product price calculation failed in Catalog Service");
        }

        OrderEntity orders = new OrderEntity();

        orders.setProductId(product.getProductId());
        orders.setCustomerId(user.getId());

        double unitPrice = product.getTotalPrice();
        orders.setPriceAtPurchase(unitPrice);

        orders.setTotalAmount(unitPrice * orderRequest.getQuantity());

        orders.setStatus(OrderStatus.CONFIRMED);
        orders.setQuantity(orderRequest.getQuantity());

        return mapToResponse(orderRepository.save(orders));
    }

    @Override
    public OrderResponse updateStatus(Long orderId, OrderStatus newStatus){
        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow(()-> new ResourceNotFoundException("Order Id not found"));

        ValidTransaction(order.getStatus(), newStatus);

        order.setStatus(newStatus);
        order.setUpdatedAt(LocalDateTime.now());

        return mapToResponse(orderRepository.save(order));
    }

    @Override
    public OrderResponse cancelOrder(Long orderId){
        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow(()-> new ResourceNotFoundException("Order Id not found"));

        ValidTransaction(order.getStatus(), OrderStatus.CANCELLED);

        order.setStatus(OrderStatus.CANCELLED);
        order.setUpdatedAt(LocalDateTime.now());

        return mapToResponse(orderRepository.save(order));
    }

    @Override
    public OrderResponse returnOrder(Long orderId){
        OrderEntity order = orderRepository.findById(orderId)
                .orElseThrow(()-> new ResourceNotFoundException("Order Id not found"));

        ValidTransaction(order.getStatus(), OrderStatus.RETURNED);

        order.setStatus(OrderStatus.RETURNED);
        order.setUpdatedAt(LocalDateTime.now());

        return mapToResponse(orderRepository.save(order));
    }

    private static final Map<OrderStatus, List<OrderStatus>> ALLOWED_TRANSITIONS = Map.of(
            OrderStatus.CONFIRMED, List.of(OrderStatus.PACKED, OrderStatus.CANCELLED),
            OrderStatus.PACKED, List.of(OrderStatus.SHIPPED, OrderStatus.CANCELLED),
            OrderStatus.SHIPPED, List.of(OrderStatus.DELIVERED),
            OrderStatus.DELIVERED, List.of(OrderStatus.RETURNED),
            OrderStatus.CANCELLED, List.of(),
            OrderStatus.RETURNED, List.of()
    );

    private void ValidTransaction(OrderStatus current, OrderStatus newStatus){
        List<OrderStatus> valid = ALLOWED_TRANSITIONS.getOrDefault(current, List.of());
        if (!valid.contains(newStatus)) {
            throw new IllegalStateException(
                    "Invalid transition: " + current + " → " + newStatus +
                            ". Allowed: " + valid
            );
        }
    }

    private OrderResponse mapToResponse(OrderEntity orderEntity){
        OrderResponse res = new OrderResponse();
        res.setOrderId(orderEntity.getOrderId());
        res.setCustomerId(orderEntity.getCustomerId());
        res.setProductId(orderEntity.getProductId());
        res.setOrderStatus(orderEntity.getStatus());
        res.setUnitPriceAtPurchase(orderEntity.getPriceAtPurchase());
        res.setTotalOrderAmount(orderEntity.getTotalAmount());
        res.setCreatedAt(orderEntity.getCreatedAt());
        res.setUpdatedAt(orderEntity.getUpdatedAt());
        return res;
    }
}

